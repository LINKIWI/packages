#!/usr/bin/env bash

set -e

function main() {
    SUBCOMMAND="$1"
    shift

    FSTOOL_DIR="$(dirname "$(readlink "${BASH_SOURCE[0]}")")"

    case "${SUBCOMMAND}" in
        "cas")
            . "${FSTOOL_DIR}/tools/cas.sh"
            cas "$@"
            ;;
        "")
            echo "fstool: no tool name supplied"
            return 1
            ;;
        *)
            echo "fstool: unsupported tool: ${SUBCOMMAND}"
            return 1
            ;;
    esac
}

main "$@"
