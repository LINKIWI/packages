#!/usr/bin/env bash

set -e

# Default rlocation implementation, which resolves the runfile literally relative to the canonical
# fstool share directory, /usr/share/fstool.
function rlocation() {
    RUNFILE="$1"

    echo "/usr/share/${RUNFILE}"
}

function main() {
    SUBCOMMAND="$1"
    shift || :

    if [[ -n "${BAZEL_RUNFILES_ENABLED}" ]]; then
        # --- begin runfiles.bash initialization v3 ---
        # Copy-pasted from the Bazel Bash runfiles library v3.
        set +e; f=bazel_tools/tools/bash/runfiles/runfiles.bash
        # shellcheck disable=SC1090
        source "${RUNFILES_DIR:-/dev/null}/$f" 2>/dev/null || \
            source "$(grep -sm1 "^$f " "${RUNFILES_MANIFEST_FILE:-/dev/null}" | cut -f2- -d' ')" 2>/dev/null || \
            source "$0.runfiles/$f" 2>/dev/null || \
            source "$(grep -sm1 "^$f " "$0.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null || \
            source "$(grep -sm1 "^$f " "$0.exe.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null || \
            { echo>&2 "ERROR: cannot find $f"; exit 1; }; f=; set -e
        # --- end runfiles.bash initialization v3 ---
    fi

    case "${SUBCOMMAND}" in
        "cas")
            . "$(rlocation "fstool/tools/cas.sh")"
            cas "$@"
            ;;
        "checksum")
            . "$(rlocation "fstool/tools/checksum.sh")"
            checksum "$@"
            ;;
        "")
            echo "fstool: no tool name supplied"
            return 1
            ;;
        *)
            echo "fstool: unsupported tool: ${SUBCOMMAND}"
            return 1
            ;;
    esac
}

main "$@"
