#!/usr/bin/env bash

# Rebuild a root directory as symlinks, keyed by file checksums.
# This is useful for reducing total data size for directories with significant content duplication.
function cas() {
    ROOT="$1"
    CAS_DIR="${2:-_}"

    if [[ -z "${ROOT}" ]]; then
        echo "fstool/cas: root directory not supplied" >&2
        return 1
    fi

    find "${ROOT}" -type f -exec sha256sum {} + | while read -r line; do
        IFS=" " read -r CHECKSUM FILE <<< "$line"
        CAS_TARGET="${ROOT}/${CAS_DIR}/${CHECKSUM:0:2}/${CHECKSUM}"

        echo "fstool/cas: processing ${FILE}: checksum ${CHECKSUM}" >&2

        mkdir -p "$(dirname "${CAS_TARGET}")"
        mv "${FILE}" "${CAS_TARGET}"
        ln -sfT "$(realpath --relative-to "$(dirname "${FILE}")" "${CAS_TARGET}")" "${FILE}"
    done
}
