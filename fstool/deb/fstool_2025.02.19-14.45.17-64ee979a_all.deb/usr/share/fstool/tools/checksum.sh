#!/usr/bin/env bash

# Derive a checksum that recursively describes a directory and all its contents.
function checksum() {
    ROOT="$1"
    CONTENT=""

    if [[ ! -d "${ROOT}" ]]; then
        echo "fstool/checksum: not a directory: ${ROOT}" >&2
        return 1
    fi

    # Regular files
    REGULAR_FILES="$(find "${ROOT}" -type f | sort)"
    if [[ -n "${REGULAR_FILES}" ]]; then
        while read -r file; do
            echo "fstool/checksum: processing regular file ${file}" >&2

            FILE_CHECKSUM="$(sha256sum "${file}")"
            CONTENT+="${FILE_CHECKSUM}"$'\n'
        done <<< "${REGULAR_FILES}"
    fi

    # Symbolic links
    SYMBOLIC_LINKS="$(find "${ROOT}" -type l | sort)"
    if [[ -n "${SYMBOLIC_LINKS}" ]]; then
        while read -r file; do
            echo "fstool/checksum: processing symbolic link ${file}" >&2

            TARGET_CHECKSUM="$(readlink "${file}" | sha256sum | awk '{print $1}')"
            CONTENT+="${TARGET_CHECKSUM}  ${file}"$'\n'
        done <<< "${SYMBOLIC_LINKS}"
    fi

    echo "$CONTENT" | sha256sum | awk '{print $1}'
}
